<?php
require_once(__DIR__ . '/inc/essentials.php');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!(isset($_SESSION['login']) && $_SESSION['login'] == true)) {
    redirect('index.php');
}

$user_id = $_SESSION['user_id'] ?? $_SESSION['id'] ?? 0;
$user_name = $_SESSION['full_name'] ?? $_SESSION['name'] ?? '';
$user_email = $_SESSION['email'] ?? '';
$user_phone = $_SESSION['phone_number'] ?? $_SESSION['phonenum'] ?? '';

$schedule_id = isset($_GET['schedule_id']) ? (int)$_GET['schedule_id'] : 0;

if ($schedule_id <= 0) {
    die("Invalid booking request.");
}

$api_url = "http://localhost:3000/api/booking-details?schedule_id=" . urlencode($schedule_id);

$api_response = @file_get_contents($api_url);

if ($api_response === false) {
    die("
        <div style='font-family: Arial, sans-serif; text-align:center; margin-top:80px;'>
            <h2 style='color:#dc3545;'>Unable to Load Booking Details</h2>
            <p>Please make sure the Node API is running.</p>
            <a href='bus.php?view=all' style='display:inline-block; margin-top:15px; padding:10px 20px; background:#172233; color:white; text-decoration:none; border-radius:6px;'>Back to Trips</a>
        </div>
    ");
}

$booking_details_response = json_decode($api_response, true);

if (
    !$booking_details_response ||
    !isset($booking_details_response['success']) ||
    $booking_details_response['success'] !== true
) {
    $message = $booking_details_response['message'] ?? 'Unable to load booking details.';

    die("
        <div style='font-family: Arial, sans-serif; text-align:center; margin-top:80px;'>
            <h2 style='color:#AD8B3A;'>Booking Not Available</h2>
            <p>" . htmlspecialchars($message) . "</p>
            <a href='bus.php?view=all' style='display:inline-block; margin-top:15px; padding:10px 20px; background:#172233; color:white; text-decoration:none; border-radius:6px;'>Back to Trips</a>
        </div>
    ");
}

$schedule = $booking_details_response['schedule'];
$bookedSeats = $booking_details_response['bookedSeats'] ?? [];

function format_time_confirm($time)
{
    if (!$time) {
        return "N/A";
    }

    return date("h:i A", strtotime($time));
}

function format_date_confirm($date)
{
    if (!$date) {
        return "N/A";
    }

    return date("M d, Y", strtotime($date));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>MYBUS - Confirm Booking</title>
    <?php require('inc/links.php'); ?>

    <style>
        .booking-page-wrap {
            max-width: 1180px;
            margin: auto;
        }

        .summary-card {
            border-radius: 14px;
            overflow: hidden;
        }

        .summary-header {
            background: #172233;
            color: #fff;
            padding: 18px 24px;
        }

        .summary-header h4 {
            font-size: 24px;
            margin-bottom: 4px;
        }

        .summary-header small {
            font-size: 14px;
        }

        .summary-body {
            padding: 22px 28px;
        }

        .summary-body h5 {
            font-size: 19px;
            margin-bottom: 14px;
        }

        .summary-label {
            font-size: 12px;
            color: #6c757d;
            margin-bottom: 5px;
        }

        .summary-value {
            font-size: 15px;
            font-weight: 700;
            color: #222;
        }

        .info-box {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 12px 14px;
            margin-bottom: 12px;
            min-height: 70px;
        }

        .gold-btn {
            background: #AD8B3A;
            color: white;
            border: none;
            padding: 8px 18px;
            font-size: 14px;
        }

        .gold-btn:hover {
            background: #8f722e;
            color: white;
        }

        .payment-note {
            background: #fff8e1;
            border-left: 5px solid #AD8B3A;
            padding: 10px 14px;
            border-radius: 8px;
            font-size: 13px;
        }

        .seat-note {
            background: #eef6ff;
            border-left: 5px solid #0d6efd;
            padding: 10px 14px;
            border-radius: 8px;
            font-size: 13px;
        }

        .online-payment-box {
            background: #f8f9fa;
            border: 1px solid #ddd;
            border-radius: 12px;
            padding: 15px;
        }

        .seat-layout-wrapper {
            background: #f8f9fa;
            border: 1px solid #ddd;
            border-radius: 14px;
            padding: 18px;
        }

        .seat-map {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(68px, 1fr));
            gap: 14px;
            max-width: 820px;
        }

        .bus-seat {
            width: 64px;
            height: 72px;
            border: 2px solid #ced4da;
            border-radius: 12px;
            background: #ffffff;
            cursor: pointer;
            position: relative;
            transition: 0.2s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 0;
        }

        .bus-seat:hover {
            transform: translateY(-2px);
            border-color: #0d6efd;
        }

        .seat-icon {
            width: 38px;
            height: 38px;
            background-color: #212529;
            mask-image: url('images/seat.png');
            -webkit-mask-image: url('images/seat.png');
            mask-size: contain;
            -webkit-mask-size: contain;
            mask-repeat: no-repeat;
            -webkit-mask-repeat: no-repeat;
            mask-position: center;
            -webkit-mask-position: center;
        }

        .seat-no {
            position: absolute;
            bottom: 4px;
            font-size: 11px;
            font-weight: 800;
            color: #212529;
        }

        .bus-seat.selected {
            background: #0d6efd;
            border-color: #0d6efd;
        }

        .bus-seat.selected .seat-icon {
            background-color: #ffffff;
        }

        .bus-seat.selected .seat-no {
            color: #ffffff;
        }

        .bus-seat.booked {
            background: #dc3545;
            border-color: #dc3545;
            cursor: not-allowed;
            opacity: 0.95;
        }

        .bus-seat.booked:hover {
            transform: none;
        }

        .bus-seat.booked .seat-icon {
            background-color: #ffffff;
        }

        .bus-seat.booked .seat-no {
            color: #ffffff;
        }

        .seat-legend {
            display: flex;
            flex-wrap: wrap;
            gap: 16px;
            margin-bottom: 15px;
        }

        .legend-item {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 13px;
        }

        .legend-seat {
            width: 30px;
            height: 30px;
            border-radius: 8px;
            border: 2px solid #ced4da;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .legend-seat::before {
            content: "";
            width: 19px;
            height: 19px;
            background-color: #212529;
            mask-image: url('images/seat.png');
            -webkit-mask-image: url('images/seat.png');
            mask-size: contain;
            -webkit-mask-size: contain;
            mask-repeat: no-repeat;
            -webkit-mask-repeat: no-repeat;
            mask-position: center;
            -webkit-mask-position: center;
        }

        .legend-available {
            background: #ffffff;
        }

        .legend-selected {
            background: #0d6efd;
            border-color: #0d6efd;
        }

        .legend-selected::before {
            background-color: #ffffff;
        }

        .legend-booked {
            background: #dc3545;
            border-color: #dc3545;
        }

        .legend-booked::before {
            background-color: #ffffff;
        }

        .selected-seat-display {
            background: #eef6ff;
            border-left: 5px solid #0d6efd;
            padding: 13px 14px;
            border-radius: 8px;
            font-size: 14px;
        }

        .dynamic-total {
            font-size: 19px;
            color: #198754;
            font-weight: 800;
        }

        .form-label {
            font-size: 14px;
        }

        .form-control {
            font-size: 14px;
        }

        .center-popup-icon {
            font-size: 50px;
        }

        .center-popup-btn {
            background: #AD8B3A;
            color: white;
            border: none;
        }

        .center-popup-btn:hover {
            background: #8f722e;
            color: white;
        }

        .btn-dark {
            padding: 8px 18px;
            font-size: 14px;
        }

        @media screen and (max-width: 768px) {
            .summary-body {
                padding: 18px;
            }

            .summary-header {
                padding: 16px 20px;
            }

            .summary-header h4 {
                font-size: 21px;
            }

            .seat-map {
                grid-template-columns: repeat(auto-fill, minmax(62px, 1fr));
            }

            .bus-seat {
                width: 60px;
                height: 68px;
            }
        }
    </style>
</head>

<body class="bg-light">

<?php require('inc/header.php'); ?>

<div class="container-fluid px-lg-4 px-md-3 px-2 booking-page-wrap">
    <div class="row">
        <div class="col-12 my-4 px-3">
            <h2 class="fw-bold h-font mb-1">CONFIRM BOOKING</h2>
            <div style="font-size:14px;">
                <a href="index.php" class="text-secondary text-decoration-none">HOME</a>
                <span class="text-secondary"> > </span>
                <a href="bus.php" class="text-secondary text-decoration-none">SEARCH TRIPS</a>
                <span class="text-secondary"> > </span>
                <span class="text-secondary">CONFIRM BOOKING</span>
            </div>
        </div>

        <div class="col-lg-11 col-md-12 mx-auto mb-5">
            <div class="card border-0 shadow summary-card">
                <div class="summary-header">
                    <h4 class="fw-bold">Booking Summary</h4>
                    <small>Please review your trip, seat, and payment details before confirming.</small>
                </div>

                <div class="summary-body">
                    <div class="row g-3">
                        <div class="col-lg-5 col-md-6">
                            <h5 class="fw-bold">Passenger Details</h5>

                            <div class="info-box">
                                <div class="summary-label">Passenger Name</div>
                                <div class="summary-value"><?php echo htmlspecialchars($user_name); ?></div>
                            </div>

                            <div class="info-box">
                                <div class="summary-label">Email</div>
                                <div class="summary-value"><?php echo htmlspecialchars($user_email); ?></div>
                            </div>

                            <div class="info-box">
                                <div class="summary-label">Phone</div>
                                <div class="summary-value"><?php echo htmlspecialchars($user_phone); ?></div>
                            </div>
                        </div>

                        <div class="col-lg-7 col-md-6">
                            <h5 class="fw-bold">Trip Details</h5>

                            <div class="row g-2">
                                <div class="col-md-6">
                                    <div class="info-box">
                                        <div class="summary-label">Route</div>
                                        <div class="summary-value">
                                            <?php echo htmlspecialchars($schedule['origin']); ?> → <?php echo htmlspecialchars($schedule['destination']); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="info-box">
                                        <div class="summary-label">Bus</div>
                                        <div class="summary-value">
                                            <?php echo htmlspecialchars($schedule['bus_number']); ?> |
                                            <?php echo htmlspecialchars($schedule['bus_type']); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="info-box">
                                        <div class="summary-label">Travel Date and Time</div>
                                        <div class="summary-value">
                                            <?php echo format_date_confirm($schedule['departure_date']); ?>
                                            |
                                            <?php echo format_time_confirm($schedule['departure_time']); ?>
                                            -
                                            <?php echo format_time_confirm($schedule['arrival_time']); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="info-box">
                                        <div class="summary-label">Fare Per Seat</div>
                                        <div class="summary-value">
                                            ₱<?php echo number_format((float)$schedule['fare'], 2); ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="info-box">
                                        <div class="summary-label">Available Seats</div>
                                        <div class="summary-value">
                                            <?php echo (int)$schedule['available_seats']; ?> seat(s)
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="info-box">
                                        <div class="summary-label">Current Total</div>
                                        <div class="summary-value fs-5 text-success" id="topTotalAmount">
                                            ₱0.00
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <hr class="my-4">

                    <h5 class="fw-bold">Seat Selection</h5>

                    <div class="seat-note mb-3">
                        Please select one or more available seat(s). Red seats are already booked.
                    </div>

                    <div class="seat-layout-wrapper mb-3">
                        <div class="seat-legend">
                            <div class="legend-item">
                                <div class="legend-seat legend-available"></div>
                                <span>Available</span>
                            </div>

                            <div class="legend-item">
                                <div class="legend-seat legend-selected"></div>
                                <span>Selected</span>
                            </div>

                            <div class="legend-item">
                                <div class="legend-seat legend-booked"></div>
                                <span>Not Available</span>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-lg-8 col-md-12 mb-3">
                                <div id="seatMap" class="seat-map"></div>
                            </div>

                            <div class="col-lg-4 col-md-12">
                                <div class="selected-seat-display">
                                    <strong>Selected Seat(s):</strong>
                                    <div id="selectedSeatText" class="mt-2">None selected</div>

                                    <hr class="my-2">

                                    <strong>Total Amount:</strong>
                                    <div id="dynamicTotalAmount" class="mt-2 dynamic-total">
                                        ₱0.00
                                    </div>
                                </div>

                                <div class="mt-3 text-muted small">
                                    Fare per seat:
                                    <strong>₱<?php echo number_format((float)$schedule['fare'], 2); ?></strong>
                                </div>
                            </div>
                        </div>
                    </div>

                    <hr class="my-4">

                    <h5 class="fw-bold">Payment Method</h5>

                    <div class="row">
                        <div class="col-md-5 mb-3">
                            <label class="form-label fw-bold">Choose Payment Method</label>
                            <select id="payment_method" class="form-control shadow-none" required>
                                <option value="Pay at Terminal">Pay at Terminal</option>
                                <option value="Online Payment">Card / Bank Payment</option>
                            </select>
                        </div>
                    </div>

                    <div class="online-payment-box d-none mb-3" id="onlinePaymentBox">
                        <h6 class="fw-bold mb-3">Card / Bank Payment Information</h6>

                        <div class="row g-2">
                            <div class="col-md-6 mb-2">
                                <label class="form-label fw-bold">Cardholder / Account Name</label>
                                <input type="text" id="account_name" class="form-control shadow-none"
                                    placeholder="Enter cardholder or account name">
                            </div>

                            <div class="col-md-6 mb-2">
                                <label class="form-label fw-bold">Card / Account Number</label>
                                <input type="text" id="account_number" class="form-control shadow-none"
                                    placeholder="Enter card or account number" maxlength="19">
                            </div>

                            <div class="col-md-3 mb-2">
                                <label class="form-label fw-bold">Expiry Date</label>
                                <input type="text" id="expiry_date" class="form-control shadow-none"
                                    placeholder="MM/YY" maxlength="5">
                            </div>

                            <div class="col-md-3 mb-2">
                                <label class="form-label fw-bold">CVV</label>
                                <input type="password" id="cvv" class="form-control shadow-none"
                                    placeholder="CVV" maxlength="4">
                            </div>

                            <div class="col-md-6 mb-2">
                                <label class="form-label fw-bold">Payment Type</label>
                                <select id="online_payment_type" class="form-control shadow-none">
                                    <option value="Card">Card</option>
                                    <option value="Bank">Bank</option>
                                </select>
                            </div>
                        </div>

                        <small class="text-muted">
                            Demo payment only. Card details are validated on the page and are not stored.
                        </small>
                    </div>

                    <div class="payment-note mb-4" id="paymentNote">
                        <strong>Pay at Terminal:</strong>
                        Your booking will be marked as pending. Please pay at the terminal.
                        Your ticket will only be available after admin confirms your payment.
                    </div>

                    <div class="d-flex gap-2">
                        <button type="button" id="confirmBookingBtn" class="btn gold-btn shadow-none">
                            Confirm Booking
                        </button>

                        <a href="bus.php?view=all" class="btn btn-dark shadow-none">
                            Back
                        </a>
                    </div>

                    <div class="mt-3 d-none" id="bookingLoader">
                        <div class="spinner-border text-warning" role="status"></div>
                        <span class="ms-2">Processing your booking...</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Booking Message Modal -->
<div class="modal fade" id="bookingMessageModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border-0 shadow rounded-4">
            <div class="modal-body text-center p-5">
                <div id="bookingMessageIcon" class="center-popup-icon mb-3">
                    ✅
                </div>

                <h5 class="fw-bold mb-2" id="bookingMessageTitle">
                    Booking Created
                </h5>

                <p class="text-muted mb-4" id="bookingMessageText">
                    Your booking has been created successfully.
                </p>

                <button type="button" class="btn center-popup-btn px-5 fw-semibold shadow-none"
                    id="bookingMessageOkBtn">
                    OK
                </button>
            </div>
        </div>
    </div>
</div>

<?php require('inc/footer.php'); ?>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const CONFIRM_BOOKING_API_BASE_URL = "http://localhost:3000/api";

    const paymentMethod = document.getElementById('payment_method');
    const onlinePaymentBox = document.getElementById('onlinePaymentBox');
    const paymentNote = document.getElementById('paymentNote');

    const accountName = document.getElementById('account_name');
    const accountNumber = document.getElementById('account_number');
    const expiryDate = document.getElementById('expiry_date');
    const cvv = document.getElementById('cvv');
    const onlinePaymentType = document.getElementById('online_payment_type');

    const confirmBookingBtn = document.getElementById('confirmBookingBtn');
    const bookingLoader = document.getElementById('bookingLoader');

    const userId = <?php echo json_encode((int)$user_id); ?>;
    const scheduleId = <?php echo json_encode((int)$schedule_id); ?>;
    const passengerName = <?php echo json_encode($user_name); ?>;
    const passengerPhone = <?php echo json_encode($user_phone); ?>;
    const passengerEmail = <?php echo json_encode($user_email); ?>;

    const maxPassengers = <?php echo json_encode((int)$schedule['available_seats']); ?>;
    const farePerSeat = <?php echo json_encode((float)$schedule['fare']); ?>;
    const busCapacity = <?php echo json_encode((int)$schedule['capacity']); ?>;
    const bookedSeats = <?php echo json_encode(array_values($bookedSeats)); ?>;

    let selectedSeats = [];

    function showBookingPopup(type, message, callback = null) {
        const modalEl = document.getElementById('bookingMessageModal');
        const icon = document.getElementById('bookingMessageIcon');
        const title = document.getElementById('bookingMessageTitle');
        const text = document.getElementById('bookingMessageText');
        const okBtn = document.getElementById('bookingMessageOkBtn');

        if (type === 'success') {
            icon.innerHTML = '✅';
            title.innerText = 'Booking Created';
        } else {
            icon.innerHTML = '❌';
            title.innerText = 'Booking Failed';
        }

        text.innerText = message;

        const modal = bootstrap.Modal.getOrCreateInstance(modalEl);
        modal.show();

        okBtn.onclick = function () {
            modal.hide();

            if (callback) {
                callback();
            }
        };
    }

    function renderSeatMap() {
        const seatMap = document.getElementById('seatMap');
        seatMap.innerHTML = '';

        for (let seat = 1; seat <= busCapacity; seat++) {
            const seatBtn = document.createElement('button');
            seatBtn.type = 'button';
            seatBtn.className = 'bus-seat';
            seatBtn.setAttribute('aria-label', 'Seat ' + seat);

            seatBtn.innerHTML = `
                <span class="seat-icon"></span>
                <span class="seat-no">${seat}</span>
            `;

            if (bookedSeats.includes(seat)) {
                seatBtn.classList.add('booked');
                seatBtn.disabled = true;
            } else {
                seatBtn.addEventListener('click', function () {
                    const seatValue = String(seat);

                    if (selectedSeats.includes(seatValue)) {
                        selectedSeats = selectedSeats.filter(s => s !== seatValue);
                        seatBtn.classList.remove('selected');
                    } else {
                        if (selectedSeats.length >= maxPassengers) {
                            showBookingPopup('error', 'You can only select up to ' + maxPassengers + ' available seat(s).');
                            return;
                        }

                        selectedSeats.push(seatValue);
                        seatBtn.classList.add('selected');
                    }

                    updateSelectedSeatText();
                });
            }

            seatMap.appendChild(seatBtn);
        }

        updateSelectedSeatText();
    }

    function updateSelectedSeatText() {
        const selectedSeatText = document.getElementById('selectedSeatText');
        const dynamicTotalAmount = document.getElementById('dynamicTotalAmount');
        const topTotalAmount = document.getElementById('topTotalAmount');

        if (selectedSeats.length === 0) {
            selectedSeatText.innerText = 'None selected';
            dynamicTotalAmount.innerText = '₱0.00';
            topTotalAmount.innerText = '₱0.00';
        } else {
            selectedSeatText.innerText = selectedSeats.join(', ');

            const totalAmount = selectedSeats.length * farePerSeat;
            const formattedTotal = '₱' + totalAmount.toLocaleString(undefined, {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });

            dynamicTotalAmount.innerText = formattedTotal;
            topTotalAmount.innerText = formattedTotal;
        }
    }

    function getSelectedSeats() {
        if (selectedSeats.length === 0) {
            showBookingPopup('error', 'Please select at least one seat.');
            return null;
        }

        return selectedSeats;
    }

    paymentMethod.addEventListener('change', function () {
        if (this.value === 'Pay at Terminal') {
            onlinePaymentBox.classList.add('d-none');

            accountName.value = '';
            accountNumber.value = '';
            expiryDate.value = '';
            cvv.value = '';

            paymentNote.innerHTML =
                "<strong>Pay at Terminal:</strong> Your booking will be marked as pending. Please pay at the terminal. Your ticket will only be available after admin confirms your payment.";
        } else {
            onlinePaymentBox.classList.remove('d-none');

            paymentNote.innerHTML =
                "<strong>Card / Bank Payment:</strong> Enter your payment details. Once the simulated payment is successful, your booking will be confirmed and your ticket will be available immediately.";
        }
    });

    function validateOnlinePayment() {
        if (paymentMethod.value === 'Pay at Terminal') {
            return true;
        }

        if (accountName.value.trim() === '') {
            showBookingPopup('error', 'Please enter the cardholder or account name.');
            accountName.focus();
            return false;
        }

        if (accountNumber.value.trim().length < 8) {
            showBookingPopup('error', 'Please enter a valid card or account number.');
            accountNumber.focus();
            return false;
        }

        if (expiryDate.value.trim() === '') {
            showBookingPopup('error', 'Please enter the expiry date.');
            expiryDate.focus();
            return false;
        }

        if (cvv.value.trim().length < 3) {
            showBookingPopup('error', 'Please enter a valid CVV.');
            cvv.focus();
            return false;
        }

        return true;
    }

    function generateOnlineReference() {
        const now = Date.now();
        const type = onlinePaymentType.value.toUpperCase();
        return type + '-PAY-' + now;
    }

    confirmBookingBtn.addEventListener('click', function () {
        const seatsToSubmit = getSelectedSeats();

        if (seatsToSubmit === null) {
            return;
        }

        if (!validateOnlinePayment()) {
            return;
        }

        const selectedPaymentMethod = paymentMethod.value;
        const generatedReferenceNo =
            selectedPaymentMethod === 'Online Payment' ? generateOnlineReference() : '';

        confirmBookingBtn.disabled = true;
        bookingLoader.classList.remove('d-none');

        fetch(`${CONFIRM_BOOKING_API_BASE_URL}/create-booking`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                user_id: userId,
                schedule_id: scheduleId,
                passenger_name: passengerName,
                phone: passengerPhone,
                email: passengerEmail,
                seats: seatsToSubmit,
                payment_method: selectedPaymentMethod,
                reference_no: generatedReferenceNo
            })
        })
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {
            console.log('Create booking response:', data);

            if (data.success) {
                showBookingPopup('success', data.message || 'Booking created successfully.', function () {
                    window.location.href = 'bookings.php';
                });
            } else {
                showBookingPopup('error', data.message || 'Failed to create booking.');
                confirmBookingBtn.disabled = false;
                bookingLoader.classList.add('d-none');
            }
        })
        .catch(function (error) {
            console.error('Booking error:', error);
            showBookingPopup('error', 'Booking failed. Please make sure the Node API is running.');
            confirmBookingBtn.disabled = false;
            bookingLoader.classList.add('d-none');
        });
    });

    renderSeatMap();
});
</script>

</body>
</html>